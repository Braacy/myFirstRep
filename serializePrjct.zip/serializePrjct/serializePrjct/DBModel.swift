//
//  DBModel.swift
//  serializePrjct
//
//  Created by Владислав  on 14.06.2024.
//

import Foundation
import ObjectMapper

class Item: Mappable {
    
    var content: String?
    var urlToImage: String?
    
    required init?(map: Map) {
    }
    
    func mapping(map: Map) {
        content <- map["content"]
        urlToImage <- map["urlToImage"]
    }
}
