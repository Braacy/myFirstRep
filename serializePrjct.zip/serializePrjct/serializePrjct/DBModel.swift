//
//  DBModel.swift
//  serializePrjct
//
//  Created by Владислав  on 14.06.2024.
//

import Foundation
import ObjectMapper

class Item: Mappable {
        var author: String?
        var title: String?
        var description: String?
        var url: String?
        var urlToImage: String?
        var publishedAt: String?
        var content: String?
    
    
    required init?(map: Map) {}
    
    func mapping(map: Map) {
        author <- map["author"]
        title <- map["title"]
        description <- map["description"]
        url <- map["url"]
        urlToImage <- map["urlToImage"]
        publishedAt <- map["publishedAt"]
        content <- map["content"]
    }
}
