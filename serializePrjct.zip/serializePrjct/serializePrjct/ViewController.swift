//
//  ViewController.swift
//  serializePrjct
//
//  Created by Владислав  on 14.06.2024.
//

import UIKit
import Alamofire
import ObjectMapper
import SDWebImage

class ViewController: UIViewController {

    
    @IBOutlet weak var myTableView: UITableView!
    
    var items: [Item] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        myTableView.dataSource = self
        myTableView.delegate = self
        
        parsData()
    }
    func parsData() {
        AF.request("https://newsapi.org/v2/everything?q=tesla&sortBy=publishedAt&apiKey=fdb5cf940ba1402cb66e2cc29b51e8d4").responseJSON { response in
//            print(response)
//            if let json = try! response.result.get() as? [[String: Any]] {
//                self.items = Mapper<Item>().mapArray(JSONArray: json)
//                self.myTableView.reloadData()
            switch response.result {
            case .success(let value):
                if let json = value as? [String: Any], let articles = json["articles"] as? [[String: Any]] {
                    self.items = Mapper<Item>().mapArray(JSONArray: articles)
                    self.myTableView.reloadData()
                } else {
                    print("Ошибка парсинга")
                }
            case .failure(let error):
                print("Ошибка запроса: \(error.localizedDescription)")
            }
        }
    }

}

extension ViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        print(items.count)
        return items.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! CustomCell
        
        let item = items[indexPath.row]
        
        cell.myLabel?.text = item.content
        
        if let imageURL = item.urlToImage, let url = URL(string: imageURL) {
           cell.myImageView?.sd_setImage(with: url, completed: nil)
     }
        return cell
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
        
    }
    
    
}
